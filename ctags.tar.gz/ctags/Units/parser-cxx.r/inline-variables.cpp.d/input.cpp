class C1
{
public:
	static inline int var1;
	inline int var2;
	
	inline void fn(){};
};

static inline int gv1;
inline int gv2;

