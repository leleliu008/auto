#ifdef SOMETHING
	namespace
#else
	class
#endif
	Name {
	};

