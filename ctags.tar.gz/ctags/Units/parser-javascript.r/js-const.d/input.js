
const A = 1;
const B = 1;
const Group = {
  X:1,
  Y:2,
  Z:3
};

const func = function () {}
