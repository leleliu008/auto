var.prototype=function(){}
