
var o = {
  "first": function(){},
  "sec\
ond": function(){},
  "\
t\
h\
i\
r\
d\
": function(){},
  "fourth": function(){},
};

o.first();
o.second();
o.third();
o.fourth();
