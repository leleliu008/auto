
var v1, v2
var v3 = 1
,   v4 = 2
,   v5 = 3
function f1() {
  var f1_c1 = {
    f1_c1_m1:
    function() {
    }
    ,
    f1_c1_m2
    :
    function
    (
    )
    {
    }
  }
}

var v6 = "hello\
var bug1 = world;"
var v7 = "hello\var bug2 = world"
var v8;
