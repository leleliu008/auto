CREATE TRIGGER [tr_d_cash_trade_comment] ON dbo.cash_trade_comment
FOR DELETE
AS
BEGIN
END
GO

