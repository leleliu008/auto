cd $(dirname "$0")

command -v cmake > /dev/null || {
    # https://cmake.org/download
    curl -LO https://github.com/Kitware/CMake/releases/download/v3.20.1/cmake-3.20.1.tar.gz
    tar vxf cmake-3.20.1.tar.gz
    cd cmake-3.20.1
    ./bootstrap
    make
    make install
}

cmake \
    -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
    -DCMAKE_VERBOSE_MAKEFILE=ON \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=`pwd`/output \
    -G "Unix Makefiles" \
    -Wno-dev \
    -S . \
    -B build.d
