typedef void (WINAPI  a) (void);
typedef void (WINAPI* b) (void);
