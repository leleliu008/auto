#include <iostream>
void foo (int &x, int y, int z)
{
	std::cin >> x;
	std::cout << y;
	std::cout << z << endl;
}
