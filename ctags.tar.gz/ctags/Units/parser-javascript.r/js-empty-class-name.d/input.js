var {prop} = { prop: "value" };
