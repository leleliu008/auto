/* https://developer.mozilla.org/en/docs/web/javascript/reference/statements/export#Using_the_default_export */

export default function cube(x) {
  return x * x * x;
}
