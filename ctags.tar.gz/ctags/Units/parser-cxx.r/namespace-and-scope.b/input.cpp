namespace X {
	void f (void);
};
void X::f (void) {}
