Tests for whitespaces

Expected output is

functions:
	a
	b
	c
	d
	e
	f
	g
	h

<?php

function	a	()	{}

function
b
()
{}

functionc(){}

functiond(){}

functione(){}

function f () {}

function	
 g	
  ()	
  {}

function h(){}


/* for live PHP tests */
var_dump(a());
var_dump(b());
var_dump(c());
var_dump(d());
var_dump(e());
var_dump(f());
var_dump(g());
var_dump(h());
