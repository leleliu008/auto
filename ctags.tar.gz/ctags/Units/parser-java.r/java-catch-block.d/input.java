// Based on code reported by @brate in #797
class C {
   public void m(String a[]) {
       try {}
       catch (Exception e) {}
   }
}
