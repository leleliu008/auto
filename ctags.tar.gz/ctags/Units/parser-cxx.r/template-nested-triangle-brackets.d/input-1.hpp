// Derived from issued #2060 submitted by @dmhacker
#include <hashtable.h>
template <class T, class Hash=std::hash<T>>
class failure {};
