var object = {
  '!hello': function(){},
  ' hello': function(){},
  '<hello': function(){},
  '>hello': function(){},
  '	hello': function(){},
  '\\hello': function(){},
  ';"hello': function(){},
  '"hello': function(){},
  "'hello": function(){},
  'hello!': function(){},
  'hello ': function(){},
};
