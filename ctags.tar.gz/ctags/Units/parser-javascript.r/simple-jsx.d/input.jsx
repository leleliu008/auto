function foo() {
  var x = <div>
    <Menu />
  <div>;

  return x;
}
