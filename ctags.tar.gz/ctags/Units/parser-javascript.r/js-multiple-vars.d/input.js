
// declarations
var a, b;
let c, d;
const A, B;

// definitions
var e = 2, f = 3;
let g = 4, h = 5;
const C = 1, D = 2;

var func1=function() { return 1; }, func2=function() { return 2; }

// with newlines in-between
var i,
    j,
    k;
var l = 2,
    m = 2,
    n = 2;

// with missing semicolons
var o = 2,
    p = 3
var q = 4
