"a".prototype = function() {}
