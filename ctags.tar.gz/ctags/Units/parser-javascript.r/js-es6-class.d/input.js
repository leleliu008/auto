
class Class1
{
	method1(arg1,arg2)
	{
	}

	method2(arg1,arg2)
	{
	}
}

class Class2
{
	static method3(arg = 10)
	{
	}
}

var Class3 = class {
	method4(){}
	static method5(){}
}

var Class4 = class Class4_2 {
	method6(){}
	static method7(){}
}

class {
	method8(n) { return n * n; }
}

function func1() {
	class InnerClass1 {
		method9() {
		}
	}
	class InnerClass2 {
		method10() {
		}
	}
}

class Class5 {
	method11() {};
	method12() {};
}

function func2() {
}
