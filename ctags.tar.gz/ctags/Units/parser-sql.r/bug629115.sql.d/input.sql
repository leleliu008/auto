/***/
DECLARE
   variable1 CLOB;
BEGIN
END;
