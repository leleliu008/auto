PROCEDURE outer_procedure IS
BEGIN
    <<my_label>>
    DECLARE
	x INTEGER;
    BEGIN
    END my_label;
END
