struct {
	int age;
} y;
