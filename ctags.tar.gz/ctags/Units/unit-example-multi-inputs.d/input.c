#include "input-0.h"

int
main(void)
{
	return 0;
}
