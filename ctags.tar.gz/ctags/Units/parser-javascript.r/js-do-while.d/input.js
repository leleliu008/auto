var v1 = 1;
// oddly enough it's perfectly valid syntax
do {} while (0) var v2 = 2;
