// Simple generic classes.
public class MyGenericClass1<T> { }

// Derived enums.
enum Enum1 : byte {
	Value1, Values
}

// Verbatim strings.
public class C {
    private string str1 = @"abc\";
    private int int1 = 123;
    private string str2 = @"abc\";
    private string str3 = "abc";
}
