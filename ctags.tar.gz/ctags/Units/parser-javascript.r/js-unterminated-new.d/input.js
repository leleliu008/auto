function f1() {
  var o1 = new Object()}
function f2() {
  var o2 = new Function()}
function f3() {
  var o3 = (new Object())}
function f4() {}
