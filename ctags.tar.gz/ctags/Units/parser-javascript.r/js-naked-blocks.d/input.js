
if (1) {
  var v1 = 1;
  {
    var v2 = 2;
  }
}

// here v1 and v2 are available
print(v1);
print(v2);
