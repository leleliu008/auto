public class C {
	public void m() {
		bool flagCheck = true;
		if (flagCheck == true) {
			Console.WriteLine("true");
		} else {
			Console.WriteLine("false");
		}
	}
}
