var x = 1;
var z = {};
var y = [];
var a = (42 + 1) * 2;
var b = 2 * (42 + 1);

