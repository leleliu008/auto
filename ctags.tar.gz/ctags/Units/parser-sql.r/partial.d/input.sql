type T is record
