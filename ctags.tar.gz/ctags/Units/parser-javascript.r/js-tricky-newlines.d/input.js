
var a = 1
,   b = 1
,   c = 1

let d
,   e
,   f

var g, h
var i, j

var k
=
function() {}
,
l
=
function(){}
