__attribute__((visibility("protected")))
        f1(int f1p1,int f1p2 __attribute__([(unused)),int f1p3)
                __attribute__ ((warn_unused_result,always_inline,deprecated))
{
