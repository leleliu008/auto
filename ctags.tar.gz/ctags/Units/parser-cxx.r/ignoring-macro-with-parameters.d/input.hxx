namespace foo _GLIBCXX_VISIBILITY(default)
{
  int x;
  _MY_INT y;
}
