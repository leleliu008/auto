Taken from an issue report (#787) by @sserbin

<?php
namespace foo;

class bar {
    public function __construct() {
    }
}
>