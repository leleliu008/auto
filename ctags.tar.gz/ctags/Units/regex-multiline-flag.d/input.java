@Subscribe
public void catchEvent(SomeEvent e)
{
    return;
}


@Subscribe
public void
    recover(Exception e)
{
    return;
}
