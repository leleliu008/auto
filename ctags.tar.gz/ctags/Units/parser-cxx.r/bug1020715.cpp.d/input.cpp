void f() {
 done(a<<1);
 a->a;
 if (a->a) {
 }
}
